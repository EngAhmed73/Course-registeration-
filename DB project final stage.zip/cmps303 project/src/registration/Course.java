package registration;

import java.io.Serializable;

public class Course implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String courseName;
	private int capacity;
	private int crn;
	private Tree<Student> enrolled;
	private LinkedQueue<Student> waitingList;

	public Course(String courseName, int capacity, int crn) {
		this.courseName = courseName;
		this.capacity = capacity;
		this.crn = crn;
		enrolled = new Tree<>();
		waitingList = new LinkedQueue<>();
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getCRN() {
		return crn;
	}

	public void setCRN(int crn) {
		this.crn = crn;
	}

	public boolean isFull() {
		if (enrolled.count() >= capacity)
			return true;

		return false;
	}

	public void addToEnrolled(Student s) {
		if (s != null)
			enrolled.insert(s.getId(), s);
	}

	public void addToWaitingList(Student s) {
		waitingList.enqueue(s);
	}

	public void removeFromEnrolled(int id) {
		enrolled.delete(id);
	}

	public Student nextFromWaitingList() {
		if (waitingList.isEmpty())
			return null;

		return waitingList.dequeue();
	}

	public void raiseCapacity(int extra) {
		capacity += extra;
		while (!isFull() && !waitingList.isEmpty()) {
			addToEnrolled(nextFromWaitingList());
		}
	}

	public void printEnrolled() {
		enrolled.traverse(2);
	}

	public boolean studentEnrolled(int id) {
		return enrolled.search(id) != null;
	}

	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", capacity=" + capacity + ", crn=" + crn + ", enrolled="
				+ enrolled.count() + ", waitingList=" + waitingList.size() + "]";
	}

}
