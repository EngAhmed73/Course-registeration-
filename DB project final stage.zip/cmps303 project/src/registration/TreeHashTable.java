package registration;

import java.io.Serializable;
import java.util.ArrayList;

public class TreeHashTable implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Course[] hashArray;
	private Course defunct;

	public TreeHashTable(int size) {
		hashArray = new Course[size];
		defunct = new Course(null, -1, -1);
	}

	private int hashFunc(int crn) {
		return crn % hashArray.length;
	}

	public int hashFunc2(int key) {
		int p = findPreviousPrime(hashArray.length);
		int h2 = p - (key % p);
		if (h2 == 0)
			return 1;
		
		return h2;
	}
 
	public void addCourse(Course course) throws Exception {
		if (search(course.getCRN()) != null)
			throw new Exception("Course Already Exists");
		
		if (!isFull()) {
			int crn = course.getCRN();
			int hashVal = hashFunc(crn);
			int h2 = hashFunc2(crn);
			while (hashArray[hashVal] != null && hashArray[hashVal] != defunct) {
				hashVal += h2;
				hashVal %= hashArray.length;
			}
			hashArray[hashVal] = course;
		} else
			throw new Exception("HashTable Is Full");
	}

	public Course search(int crn) {
		int hashVal = hashFunc(crn);
		int h2 = hashFunc2(crn);
		while (hashArray[hashVal] != null) {
			if (hashArray[hashVal].getCRN() == crn)
				return hashArray[hashVal];

			hashVal += h2;
			hashVal %= hashArray.length;
		}
		return null;
	}

	public void addStudent(int crn, Student s) throws Exception {
		Course course = search(crn);
		if (course == null)
			throw new Exception("Course Not Found");

		if (course.isFull())
			course.addToWaitingList(s);
		else
			course.addToEnrolled(s);
	}

	public void dropStudent(int crn, int id) throws Exception {
		Course course = search(crn);
		if (course == null)
			throw new Exception("Course Not Found");

		course.removeFromEnrolled(id);

		Student add = course.nextFromWaitingList();
		if (add != null)
			course.addToEnrolled(add);
	}

	public void raiseCapacity(int crn, int extra) throws Exception {
		Course course = search(crn);
		if (course == null)
			throw new Exception("Course Not Found");

		course.raiseCapacity(extra);
	}

	public void printStudents(int crn) throws Exception {
		Course course = search(crn);
		if (course == null)
			throw new Exception("Course Not Found");

		course.printEnrolled();
	}

	public Course[] studentEnrolled(int i) throws Exception {
		ArrayList<Course> temp = new ArrayList<>();
		boolean exists = false;
		Course course;
		for (int k = 0; k < hashArray.length; k++) {
			if (hashArray[k] == null || hashArray[k] == defunct)
				continue;

			course = hashArray[k];
			if (course.studentEnrolled(i)) {
				temp.add(course);
				exists = true;
			}
		}
		Course[] courses = temp.toArray(new Course[0]);

		if (!exists)
			throw new Exception("Student Not Found");

		return courses;
	}

	public boolean isFull() {
		for (int i = 0; i < hashArray.length; i++)
			if (hashArray[i] == null || hashArray[i] == defunct)
				return false;
		return true;

	}

	private int findPreviousPrime(int n) {
		for (int i = n; i >= 2; i--) {
			if (isPrime(i))
				return i;
		}
		return 3;
	}

	private boolean isPrime(int n) {
		if (n < 2)
			return false;
		for (int i = 2; i * i <= n; i++) {
			if (n % i == 0)
				return false;
		}
		return true;
	}

}
