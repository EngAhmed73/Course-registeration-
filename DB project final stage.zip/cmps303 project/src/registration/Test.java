//Amro Arbab 202309801
//Ahmed Hassanien 202307933
//Karim Elnaggar 202307871
//Vael Fazelrahman 202307899

package registration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Scanner;

public class Test implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void save(TreeHashTable table) {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("courses.ser"))) {
			oos.writeObject(table);
		} catch (IOException e) {
			System.out.println("Failed to save data");
		}
	}

	public static TreeHashTable load() {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("courses.ser"))) {
			return (TreeHashTable) ois.readObject();
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("No previous data found. Starting fresh.");
			return new TreeHashTable(50);
		}
	}

	public static void main(String[] args) {

		TreeHashTable tht = load();
		Scanner scanner = new Scanner(System.in);
		int i = 1;

		while (i > 0) {
			System.out.println("\nEnter your choice:");
			System.out.println("1- Add a new course");
			System.out.println("2- Add a student to a course");
			System.out.println("3- Drop a student from a course");
			System.out.println("4- Raise course's capacity");
			System.out.println("5- Display students in a course");
			System.out.println("6- Display student's courses");
			System.out.println("7- Exit");

			try {
				System.out.print("> ");
				int choice = Integer.parseInt(scanner.nextLine());

				switch (choice) {
				case 1:
					try {
						System.out.print("Enter course CRN: ");
						int crn = Integer.parseInt(scanner.nextLine());

						System.out.print("Enter course name: ");
						String name = scanner.nextLine();

						System.out.print("Enter course capacity: ");
						int capacity = Integer.parseInt(scanner.nextLine());

						Course crs = new Course(name, capacity, crn);

						tht.addCourse(crs);
						System.out.println("Course added successfully");

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");

					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 2:
					try {
						System.out.print("Enter course CRN: ");
						int crn = Integer.parseInt(scanner.nextLine());

						System.out.print("Enter student ID: ");
						int id = Integer.parseInt(scanner.nextLine());

						System.out.print("Enter student name: ");
						String studentName = scanner.nextLine();

						Student stdnt = new Student(id, studentName);

						tht.addStudent(crn, stdnt);
						System.out.println("Student added successfully");

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");
					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 3:
					try {
						System.out.print("Enter course CRN: ");
						int crn = Integer.parseInt(scanner.nextLine());

						System.out.print("Enter student ID: ");
						int id = Integer.parseInt(scanner.nextLine());

						tht.dropStudent(crn, id);
						System.out.println("Student dropped successfully");

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");
					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 4:
					try {
						System.out.print("Enter course CRN: ");
						int crn = Integer.parseInt(scanner.nextLine());

						System.out.print("Enter capacity increase: ");
						int increase = Integer.parseInt(scanner.nextLine());

						tht.raiseCapacity(crn, increase);
						System.out.println("Capacity increased successfully");

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");
					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 5:
					try {

						System.out.print("Enter course CRN: ");
						int crn = Integer.parseInt(scanner.nextLine());
						tht.printStudents(crn);

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");
					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 6:
					try {
						System.out.print("Enter student ID: ");
						int id = Integer.parseInt(scanner.nextLine());
						Course[] courses = tht.studentEnrolled(id);
						System.out.println(Arrays.toString(courses));

					} catch (NumberFormatException e) {
						System.out.println("Invalid number format");
					} catch (Exception e) {
						System.out.println("Error: " + e.getMessage());
					}

					break;

				case 7:
					save(tht);
					System.out.println("Data saved successfully. Goodbye!");
					scanner.close();
					i = -1;

					break;

				default:
					System.out.println("Invalid choice. Please enter 1-7");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a number between 1-7");
			}
		}

	}

}
